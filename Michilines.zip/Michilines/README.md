# Michilines Github del TP
  
  ### Trello: https://trello.com/b/ICiYxbN6/michilines
  
  ### Miro:  https://miro.com/app/board/uXjVLM0d6n8=/
  
  ### Herramienta para la app de celu: https://kivy.org
